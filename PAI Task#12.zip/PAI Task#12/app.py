from flask import Flask, render_template, request
import faiss
import pickle
import numpy as np
from sentence_transformers import SentenceTransformer

app = Flask(__name__)

# Load MiniLM model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Load FAISS index
index = faiss.read_index("faiss_index.bin")

# Load questions
with open("questions.pkl", "rb") as f:
    questions = pickle.load(f)

# Load answers
with open("answers.pkl", "rb") as f:
    answers = pickle.load(f)


# Greeting responses
greetings = {
    "hi": "Hi! How can I help you with university admissions?",
    "hello": "Hello! How can I help you with university admissions?",
    "hey": "Hey! Ask me anything related to university admissions.",
    "good morning": "Good morning! How may I help you?",
    "good evening": "Good evening! Ask your admission related questions.",
    "how are you": "I am fine and ready to help you.",
    "thanks": "You are welcome!",
    "thank you": "Glad to help you!",
    "bye": "Goodbye! Have a great day!"
}


@app.route("/", methods=["GET", "POST"])
def home():

    answer = ""

    if request.method == "POST":

        # Get user question
        user_question = request.form["question"].lower().strip()

        # Check greetings first
        if user_question in greetings:

            answer = greetings[user_question]

        else:

            # Convert question into embedding
            query_embedding = model.encode([user_question])

            query_embedding = np.array(query_embedding).astype('float32')

            # Search most similar question
            distances, indices = index.search(query_embedding, 1)

            best_match = indices[0][0]

            distance = distances[0][0]

            # Irrelevant question handling
            if distance > 1.5:

                answer = "Please ask questions related to university admissions only."

            else:

                answer = answers[best_match]

    return render_template("index.html", answer=answer)


if __name__ == "__main__":
    app.run(debug=True)