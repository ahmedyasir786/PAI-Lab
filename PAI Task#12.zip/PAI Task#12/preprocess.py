import pandas as pd
import numpy as np
import faiss
import pickle
from sentence_transformers import SentenceTransformer

# Load CSV
df = pd.read_csv("university_faq.csv")

questions = df["question"].tolist()
answers = df["answer"].tolist()

# Load MiniLM model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Create embeddings
embeddings = model.encode(questions)

# Convert to numpy array
embeddings = np.array(embeddings).astype('float32')

# Create FAISS index
dimension = embeddings.shape[1]

index = faiss.IndexFlatL2(dimension)

index.add(embeddings)

# Save index
faiss.write_index(index, "faiss_index.bin")

# Save questions and answers
with open("questions.pkl", "wb") as f:
    pickle.dump(questions, f)

with open("answers.pkl", "wb") as f:
    pickle.dump(answers, f)

print("FAISS Index Created Successfully")