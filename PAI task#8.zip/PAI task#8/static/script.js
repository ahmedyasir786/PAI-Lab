function getJoke(){

fetch("/get_joke")

.then(response => response.json())

.then(data => {

document.getElementById("setup").innerText = data.setup
document.getElementById("punchline").innerText = data.punchline

})

}