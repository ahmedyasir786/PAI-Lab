from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import cv2
import os
from ultralytics import YOLO

app = Flask(__name__)

# Load YOLO model (automatically downloads yolov8n.pt if not present)
model = YOLO("yolov8n.pt")

UPLOAD_FOLDER = "static/uploads"
# os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# Animal classes from COCO dataset
ANIMALS = ["cow", "sheep", "horse", "dog", "cat", "elephant", "zebra", "giraffe"]

def detect_herd(image_path):
    img = cv2.imread(image_path)
    results = model(img)

    animal_count = 0
    herd_detected = False

    for r in results:
        boxes = r.boxes
        for box in boxes:
            cls_id = int(box.cls[0])
            label = model.names[cls_id]

            if label in ANIMALS:
                animal_count += 1
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(img, label, (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # Herd logic (if more than 3 animals = herd)
    if animal_count >= 3:
        herd_detected = True

    output_path = os.path.join(app.config["UPLOAD_FOLDER"], "output.jpg")
    cv2.imwrite(output_path, img)

    return animal_count, herd_detected, output_path


@app.route("/", methods=["GET", "POST"])
def index():
    animal_count = 0
    herd_detected = False
    output_image = None

    if request.method == "POST":
        file = request.files["file"]
        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            file.save(filepath)

            animal_count, herd_detected, output_image = detect_herd(filepath)

    return render_template("index.html",
                           animal_count=animal_count,
                           herd_detected=herd_detected,
                           output_image=output_image)


if __name__ == "__main__":
    app.run(debug=True)