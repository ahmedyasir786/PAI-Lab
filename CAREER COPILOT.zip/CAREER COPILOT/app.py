from flask import Flask, render_template, request, redirect, session
import os

from config import UPLOAD_FOLDER, SECRET_KEY

from models.resume_parser import extract_text
from models.skill_extractor import extract_skills
from models.matcher import match_skills
from models.cover_letter import generate_cover
from models.interview import get_questions
from models.recommender import recommend
from models.insights import get_insights
from models.learning import get_courses

from utils.json_handler import read_json, write_json

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# ---------------- USERS ----------------
def load_users():
    return read_json("data/users.json")

def save_users(data):
    write_json("data/users.json", data)

# ---------------- HISTORY ----------------
def save_history(user, score):
    history = read_json("data/history.json")

    history.append({
        "user": user,
        "score": score
    })

    write_json("data/history.json", history)

# ---------------- ACTIVITY ----------------
def log_activity(user, action, data=""):
    logs = read_json("data/activity.json")

    logs.append({
        "user": user,
        "action": action,
        "data": data
    })

    write_json("data/activity.json", logs)

# ---------------- ROUTES ----------------
@app.route("/")
def home():
    return render_template("index.html")

# REGISTER
@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        users = load_users()
        users.append({
            "email": request.form["email"],
            "password": request.form["password"]
        })
        save_users(users)
        return redirect("/login")
    return render_template("register.html")

# LOGIN
@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        users = load_users()
        for u in users:
            if u["email"] == email and u["password"] == password:
                session.clear()
                session["user"] = email
                return redirect("/dashboard")

    return render_template("login.html")

# DASHBOARD
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/login")
    return render_template("dashboard.html")

# ---------------- RESUME ANALYZER ----------------
@app.route("/upload", methods=["GET","POST"])
def upload():
    if "user" not in session:
        return redirect("/login")

    if request.method == "POST":
        file = request.files["resume"]
        job = request.form["job"]

        path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
        file.save(path)

        text = extract_text(path)
        res_skills = extract_skills(text)
        job_skills = extract_skills(job)

        score, matched, missing = match_skills(res_skills, job_skills)
        recommendations = recommend(missing)

        # SAVE HISTORY
        save_history(session["user"], score)

        # SAVE FOR INSIGHTS
        session["last_analysis"] = {
            "matched": matched,
            "missing": missing
        }

        # GET USER HISTORY
        history = read_json("data/history.json")
        user_scores = [h["score"] for h in history if h["user"] == session["user"]]

        log_activity(session["user"], "Resume Analysis", file.filename)

        return render_template("result.html",
                               score=score,
                               matched=matched,
                               missing=missing,
                               recommendations=recommendations,
                               history=user_scores)

    return render_template("upload.html")

# ---------------- COVER LETTER ----------------
@app.route("/cover", methods=["GET","POST"])
def cover():
    if "user" not in session:
        return redirect("/login")

    if request.method == "POST":
        name = request.form["name"]
        role = request.form["role"]

        letter = generate_cover(name, role)

        log_activity(session["user"], "Cover Letter", role)

        return render_template("cover_letter.html", letter=letter)

    return render_template("cover_letter.html")

# ---------------- INTERVIEW ----------------
@app.route("/interview", methods=["GET","POST"])
def interview():
    if "user" not in session:
        return redirect("/login")

    questions = []

    if request.method == "POST":
        topic = request.form["topic"]
        questions = get_questions(topic)

        log_activity(session["user"], "Interview Topic", topic)

    return render_template("interview.html", questions=questions)

# ---------------- SKILL INSIGHTS ----------------
@app.route("/insights")
def insights():
    if "user" not in session:
        return redirect("/login")

    data = session.get("last_analysis", None)

    if data:
        matched = data["matched"]
        missing = data["missing"]

        total = len(matched)

        if total >= 5:
            msg = "Excellent profile 🔥"
        elif total >= 3:
            msg = "Good but can improve 👍"
        else:
            msg = "Need improvement ⚠️"

        result = {
            "matched": len(matched),
            "missing": len(missing),
            "message": msg
        }
    else:
        result = {
            "matched": 0,
            "missing": 0,
            "message": "No analysis done yet"
        }

    return render_template("insights.html", data=result)

# ---------------- LEARNING PATHS ----------------
@app.route("/learning")
def learning():
    if "user" not in session:
        return redirect("/login")

    courses = get_courses()

    log_activity(session["user"], "Viewed Learning")

    return render_template("learning.html", courses=courses)

# ---------------- ADMIN ----------------
@app.route("/admin", methods=["GET","POST"])
def admin():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username == "Ahmed" and password == "12345":
            session["admin"] = True
            return redirect("/admin")

    if "admin" not in session:
        return render_template("admin_login.html")

    users = read_json("data/users.json")
    activity = read_json("data/activity.json")

    return render_template("admin.html", users=users, activity=activity)

# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# ---------------- RUN ----------------
if __name__ == "__main__":
    app.run(debug=True)