import os

def save_file(file, upload_folder):
    path = os.path.join(upload_folder, file.filename)
    file.save(path)
    return path