def get_questions(topic):

    topic = topic.lower()

    data = {
        "python": [
            ("What is Python?", "Python is a high-level programming language used for web, AI, and automation."),
            ("Explain list vs tuple", "Lists are mutable while tuples are immutable."),
            ("What is OOP?", "OOP is a programming concept based on objects and classes."),
            ("What is a function?", "A function is a reusable block of code."),
            ("Explain loops", "Loops are used to repeat a block of code."),
            ("What is dictionary?", "A dictionary stores data in key-value pairs."),
            ("What is lambda?", "Lambda is an anonymous function."),
            ("What is exception handling?", "It is used to handle runtime errors."),
            ("What is module?", "A module is a file containing Python code."),
            ("What is class?", "A class is a blueprint for creating objects.")
        ],

        "web": [
            ("What is HTML?", "HTML is used to structure web pages."),
            ("What is CSS?", "CSS is used to style web pages."),
            ("What is JavaScript?", "JavaScript adds interactivity to websites."),
            ("What is Flask?", "Flask is a Python web framework."),
            ("What is API?", "API allows communication between systems."),
            ("What is REST?", "REST is a web service architecture."),
            ("What is HTTP?", "HTTP is a protocol for communication."),
            ("Frontend vs Backend?", "Frontend is UI, backend handles logic."),
            ("What is full stack?", "Full stack means frontend + backend."),
            ("What is DOM?", "DOM represents HTML structure.")
        ],

        "database": [
            ("What is SQL?", "SQL is used to manage databases."),
            ("What is DBMS?", "DBMS is software to manage data."),
            ("What is primary key?", "It uniquely identifies a record."),
            ("What is foreign key?", "It links two tables."),
            ("What is normalization?", "It reduces data redundancy."),
            ("What is join?", "Join combines data from tables."),
            ("What is index?", "Index improves query speed."),
            ("What is NoSQL?", "NoSQL stores non-tabular data."),
            ("SQL vs NoSQL?", "SQL is structured, NoSQL is flexible."),
            ("What is query?", "Query is used to retrieve data.")
        ]
    }

    return data.get(topic, [("No questions found", "Try another topic")])