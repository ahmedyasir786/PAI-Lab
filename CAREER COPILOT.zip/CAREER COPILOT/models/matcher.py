def match_skills(resume_skills, job_skills):

    matched = []
    missing = []

    # ensure unique comparison
    job_skills = list(set(job_skills))

    for skill in job_skills:
        if skill in resume_skills:
            matched.append(skill)
        else:
            missing.append(skill)

    # score based on ALL skills (not partial)
    if len(job_skills) == 0:
        score = 0
    else:
        score = int((len(matched) / len(job_skills)) * 100)

    return score, matched, missing