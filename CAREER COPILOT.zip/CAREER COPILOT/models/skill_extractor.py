skills = [
    "python","java","sql","html","css","javascript",
    "flask","django","react","node","c++"
]

def extract_skills(text):
    text = text.lower()
    found = []

    for skill in skills:
        if skill in text:
            found.append(skill)

    return found