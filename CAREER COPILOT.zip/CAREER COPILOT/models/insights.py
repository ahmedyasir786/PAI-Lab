def get_insights(skills):

    total = len(skills)

    if total >= 5:
        msg = "Excellent profile 🔥"
    elif total >= 3:
        msg = "Good but can improve 👍"
    else:
        msg = "Need improvement ⚠️"

    return {
        "total_skills": total,
        "message": msg
    }