def get_courses():
    return [
        "Python Full Course - YouTube",
        "Web Development Bootcamp - Udemy",
        "SQL for Beginners - Coursera",
        "Data Structures & Algorithms - Udemy",
        "Machine Learning Basics - Coursera",
        "Flask Web Development - YouTube",
        "React JS Complete Guide - Udemy",
        "Git & GitHub Mastery - YouTube",
        "Docker Basics - Udemy",
        "System Design Fundamentals - YouTube"
    ]