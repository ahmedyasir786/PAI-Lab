import PyPDF2

def extract_text(path):
    text = ""
    pdf = PyPDF2.PdfReader(path)
    for page in pdf.pages:
        text += page.extract_text()
    return text.lower()