def generate_cover(name, role):

    return f"""
Hi, I am {name}.

I am applying for the position of {role}.

I am a student of BS Artificial Intelligence and highly interested in this opportunity.

I believe my skills and passion make me a strong candidate.

Thank you for your consideration.
"""