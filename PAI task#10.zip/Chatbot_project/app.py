from flask import Flask, render_template, request, jsonify
from datetime import datetime

app = Flask(__name__)

programs = {
    "bscs": {"fee": "100,000 - 130,000", "campus": "Main Campus"},
    "bba": {"fee": "90,000 - 120,000", "campus": "City Campus"},
    "ai": {"fee": "120,000 - 150,000", "campus": "Main Campus"},
    "engineering": {"fee": "110,000 - 150,000", "campus": "Engineering Block"}
}

campuses = {
    "main campus": {
        "address": "Raiwind Road, Lahore",
        "programs": ["BSCS", "AI", "Engineering"]
    },
    "city campus": {
        "address": "Johar Town, Lahore",
        "programs": ["BBA", "Business"]
    },
    "engineering block": {
        "address": "Engineering Block, Lahore",
        "programs": ["Engineering", "Robotics"]
    }
}

def get_response(msg):
    msg = msg.lower().strip()

    # 🔹 FIX: fee query FIRST (important)
    if "fee" in msg:
        for p in programs:
            if p in msg:
                data = programs[p]
                return f"{p.upper()} fee is {data['fee']} per semester."

        return "Fee structure ranges from 90,000 to 150,000 depending on program."

    # 🔹 PROGRAM INFO
    for p in programs:
        if p in msg:
            data = programs[p]
            return f"{p.upper()} is offered at {data['campus']} with fee {data['fee']}."

    # 🔹 CAMPUS INFO
    for c in campuses:
        if c in msg:
            data = campuses[c]
            return f"📍 Address: {data['address']} | Programs: {', '.join(data['programs'])}"

    # 🔹 GENERAL
    if "admission" in msg:
        return "Admission requires online form and entry test."
    elif "deadline" in msg:
        return "Admission deadline is August every year."
    elif "campus" in msg:
        return "We have Main Campus, City Campus, Engineering Block."

    return "Please ask about programs, fee, campus, admission or deadline."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def chat():
    msg = request.form["message"]
    reply = get_response(msg)

    return jsonify({
        "reply": reply,
        "time": datetime.now().strftime("%H:%M")
    })

if __name__ == "__main__":
    app.run(debug=True)